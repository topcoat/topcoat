button
======

### TopCoat button base

This is the base for all TopCoat buttons.
Extend this button in your theme to add styling and behaviors.
All platform specific prefixes should be added by the theme as well.
